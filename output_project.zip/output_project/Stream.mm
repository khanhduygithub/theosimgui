#import <UIKit/UIKit.h>
#import <objc/runtime.h>

// Global variables
BOOL StreamMode = NO;
UIView *protectedView = nil;

// Base64 decode helper
static NSString* DecodeBase64String(const char *b64) {
    NSData *data = [[NSData alloc] initWithBase64EncodedString:[NSString stringWithUTF8String:b64]
                                                       options:NSDataBase64DecodingIgnoreUnknownCharacters];
    if (!data) return nil;
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
}

// Core hiding function
BOOL __fn_hideCaptureForView(UIView *v, BOOL hidden) {
    static dispatch_once_t __once;
    static NSString *__maskKey = nil;
    
    dispatch_once(&__once, ^{
        // "disableUpdateMask" in base64
        const char *b64 = "ZGlzYWJsZVVwZGF0ZU1hc2s=";
        __maskKey = DecodeBase64String(b64);
    });
    
    if (!v) return NO;
    
    if (!__maskKey || ![v.layer respondsToSelector:NSSelectorFromString(__maskKey)]) {
        return NO;
    }
    
    NSInteger value = hidden ? ((1 << 1) | (1 << 4)) : 0;
    
    @try {
        [v.layer setValue:@(value) forKey:__maskKey];
        return YES;
    }
    @catch (NSException *exception) {
        return NO;
    }
}

// Update protection for a specific view
void UpdateStreamProtectionForView(UIView *view) {
    if (!view) return;
    
    protectedView = view;
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"StreamMode"]) {
        StreamMode = [defaults boolForKey:@"StreamMode"];
    }
    
    __fn_hideCaptureForView(view, StreamMode);
}

// Set stream mode globally
void SetStreamMode(BOOL value) {
    StreamMode = value;
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:value forKey:@"StreamMode"];
    [defaults synchronize];
    
    if (protectedView) {
        __fn_hideCaptureForView(protectedView, value);
    }
}

// Auto-restore stream mode on app launch
__attribute__((constructor))
static void __applyStreamerMode(void) {
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        if ([defaults objectForKey:@"StreamMode"]) {
            StreamMode = [defaults boolForKey:@"StreamMode"];
        }
        
        if (protectedView) {
            __fn_hideCaptureForView(protectedView, StreamMode);
        }
    });
}
