   
#import "EtcHostsURLProtocol.h"

static NSString * const EtcHostModifiedPropertyKey = @"EtcHostModifiedProperty";

@interface EtcHostsConfiguration : NSObject <EtcHostsConfiguration>
- (NSString *)IPAddressForHostName:(NSString *)hostName;
@end

#pragma mark -

@interface EtcHostsURLProtocol () <NSURLSessionDataDelegate>
@property (readwrite, nonatomic, strong) NSURLSessionDataTask *dataTask;
@end

@implementation EtcHostsURLProtocol

+ (EtcHostsConfiguration *)sharedConfiguration {
    static EtcHostsConfiguration * _sharedConfiguration = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedConfiguration = [[EtcHostsConfiguration alloc] init];
    });

    return _sharedConfiguration;
}

+ (void)configureHostsWithBlock:(void (^)(id <EtcHostsConfiguration> configuration))block {
    if (block) {
        block([self sharedConfiguration]);
    }
}

#pragma mark - NSURLProtocol

+ (BOOL)canInitWithRequest:(NSURLRequest *)request {
    return [[self sharedConfiguration] IPAddressForHostName:[[request URL] host]] && ([[[request URL] scheme] caseInsensitiveCompare:@"http"] == NSOrderedSame || [[[request URL] scheme] caseInsensitiveCompare:@"https"] == NSOrderedSame);
}

+ (NSURLRequest *)canonicalRequestForRequest:(NSURLRequest *)request {
    NSMutableURLRequest *mutableRequest = [request mutableCopy];

    NSURLComponents *URLComponents = [NSURLComponents componentsWithString:[[mutableRequest URL] absoluteString]];
    URLComponents.scheme = @"http";
    URLComponents.host = [[[self class] sharedConfiguration] IPAddressForHostName:URLComponents.host];

    mutableRequest.URL = [URLComponents URL];

    [NSURLProtocol setProperty:@(YES) forKey:EtcHostModifiedPropertyKey inRequest:mutableRequest];

    return mutableRequest;
}

- (void)startLoading {
    NSURLRequest *canonicalRequest = [[self class] canonicalRequestForRequest:self.request];
    NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:config delegate:self delegateQueue:nil];
    self.dataTask = [session dataTaskWithRequest:canonicalRequest];
    [self.dataTask resume];
}

- (void)stopLoading {
    [self.dataTask cancel];
    self.dataTask = nil;
}

#pragma mark - NSURLSessionDataDelegate

- (void)URLSession:(NSURLSession *)session
          dataTask:(NSURLSessionDataTask *)dataTask
didReceiveResponse:(NSURLResponse *)response
 completionHandler:(void (^)(NSURLSessionResponseDisposition))completionHandler
{
    [[self client] URLProtocol:self didReceiveResponse:response cacheStoragePolicy:NSURLCacheStorageAllowed];
    completionHandler(NSURLSessionResponseAllow);
}

- (void)URLSession:(NSURLSession *)session
          dataTask:(NSURLSessionDataTask *)dataTask
    didReceiveData:(NSData *)data
{
    [[self client] URLProtocol:self didLoadData:data];
}

- (void)URLSession:(NSURLSession *)session
          dataTask:(NSURLSessionDataTask *)dataTask
 willCacheResponse:(NSCachedURLResponse *)proposedResponse
 completionHandler:(void (^)(NSCachedURLResponse *))completionHandler
{
    completionHandler(proposedResponse);
}

#pragma mark - NSURLSessionTaskDelegate

- (void)URLSession:(NSURLSession *)session
              task:(NSURLSessionTask *)task
didCompleteWithError:(NSError *)error
{
    if (error) {
        [[self client] URLProtocol:self didFailWithError:error];
    } else {
        [[self client] URLProtocolDidFinishLoading:self];
    }
}

- (void)URLSession:(NSURLSession *)session
              task:(NSURLSessionTask *)task
didReceiveChallenge:(NSURLAuthenticationChallenge *)challenge
 completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential *))completionHandler
{
    [[self client] URLProtocol:self didReceiveAuthenticationChallenge:challenge];
    completionHandler(NSURLSessionAuthChallengePerformDefaultHandling, nil);
}

@end

#pragma mark -

@interface EtcHostsConfiguration ()
@property (readwrite, nonatomic, strong) NSMutableDictionary *mutableIPAddressesByHostName;
@end

@implementation EtcHostsConfiguration

- (instancetype)init {
    self = [super init];
    if (!self) {
        return nil;
    }

    self.mutableIPAddressesByHostName = [[NSMutableDictionary alloc] init];

    return self;
}

- (NSString *)IPAddressForHostName:(NSString *)hostName {
    return self.mutableIPAddressesByHostName[hostName];
}

#pragma mark - EtcHostsConfiguration

- (void)resolveHostName:(NSString *)hostName
            toIPAddress:(NSString *)IPAddress
{
    NSParameterAssert(hostName);
    NSParameterAssert(IPAddress);

    self.mutableIPAddressesByHostName[[hostName lowercaseString]] = IPAddress;
}

@end
